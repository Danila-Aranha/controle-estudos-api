// Importa as dependências
const express = require('express');
const mysql = require('mysql2');

// Cria a aplicação Express
const app = express();

// Permite receber JSON no body das requisições
app.use(express.json());
// Servir arquivos estáticos da pasta frontend
app.use(express.static('frontend'));


// Configura a conexão com o banco de dados
const conexao = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'DanilaMySQL*', // sua senha
  database: 'controle_estudos'
});

// Testa a conexão com o banco de dados
conexao.connect((err) => {
  if (err) {
    console.error('Erro ao conectar no banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados!');
});

// Rota GET padrão
app.get('/', (req, res) => {
  res.send('Servidor funcionando! 🚀');
});

// Rota GET para listar estudos
app.get('/estudos', (req, res) => {
  const query = 'SELECT * FROM estudos';
  conexao.query(query, (err, resultados) => {
    if (err) {
      console.error('Erro ao buscar estudos:', err);
      res.status(500).send('Erro ao buscar estudos');
      return;
    }
    res.status(200).json(resultados);
  });
});

// Buscar estudo por ID
app.get('/estudos/:id', (req, res) => {
  const { id } = req.params;
  const query = 'SELECT * FROM estudos WHERE id = ?';
  conexao.query(query, [id], (err, resultado) => {
    if (err) {
      console.error('Erro ao buscar estudo:', err);
      res.status(500).send('Erro ao buscar estudo');
      return;
    }

    if (resultado.length === 0) {
      res.status(404).send('Estudo não encontrado');
      return;
    }

    res.status(200).json(resultado[0]);
  });
});


// Rota POST para cadastrar estudo
app.post('/cadastro', (req, res) => {
  const { titulo, descricao } = req.body;

  const query = 'INSERT INTO estudos (titulo, descricao) VALUES (?, ?)';
  conexao.query(query, [titulo, descricao], (err, resultado) => {
    if (err) {
      console.error('Erro ao inserir dados:', err);
      res.status(500).send('Erro ao cadastrar');
      return;
    }
    res.status(201).send('Cadastro realizado com sucesso!');
  });
});

//Rota PUT 
app.put('/estudos/:id', (req, res) => {
  const { id } = req.params; // pega o id da URL
  const { titulo, descricao } = req.body; // pega os dados do corpo da requisição

  const query = 'UPDATE estudos SET titulo = ?, descricao = ? WHERE id = ?';
  conexao.query(query, [titulo, descricao, id], (err, resultado) => {
    if (err) {
      console.error('Erro ao atualizar estudo:', err);
      res.status(500).send('Erro ao atualizar estudo');
      return;
    }
    if (resultado.affectedRows === 0) {
      res.status(404).send('Estudo não encontrado');
      return;
    }
    res.send('Estudo atualizado com sucesso!');
  });
});


//Rota para DELETAR estudo
app.delete('/estudos/:id', (req, res) => {
  const { id } = req.params;

  const query = 'DELETE FROM estudos WHERE id = ?';
  conexao.query(query, [id], (err, resultado) => {
    if (err) {
      console.error('Erro ao deletar estudo:', err);
      res.status(500).send('Erro ao deletar');
      return;
    }
    if (resultado.affectedRows === 0) {
      res.status(404).send('Estudo não encontrado');
      return;
    }
    res.status(200).send('Estudo deletado com sucesso!');
  });
});


// Inicia o servidor
app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000 🚀');
});

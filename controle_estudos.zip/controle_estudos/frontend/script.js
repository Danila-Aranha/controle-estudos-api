const listaEstudos = document.getElementById('lista-estudos');
const formEstudo = document.getElementById('form-estudo');
const tituloInput = document.getElementById('titulo');
const descricaoInput = document.getElementById('descricao');

let estudoEditandoId = null; // controla se está editando

// Carregar estudos
function carregarEstudos() {
  fetch('http://localhost:3000/estudos')
    .then(res => res.json())
    .then(estudos => {
      listaEstudos.innerHTML = '';
      estudos.forEach(estudo => {
        const li = document.createElement('li');
        li.classList.add('estudo-card');

        const tituloStrong = document.createElement('strong');
        tituloStrong.textContent = estudo.titulo;

        const descricaoSpan = document.createElement('span');
        descricaoSpan.textContent = ` - ${estudo.descricao} `;

        const btnEditar = document.createElement('button');
        btnEditar.textContent = '✏️';
        btnEditar.addEventListener('click', () => {
          editarEstudo(estudo.id, estudo.titulo, estudo.descricao);
        });

        const btnDeletar = document.createElement('button');
        btnDeletar.textContent = '🗑️';
        btnDeletar.addEventListener('click', () => {
          deletarEstudo(estudo.id);
        });

        li.appendChild(tituloStrong);
        li.appendChild(descricaoSpan);
        li.appendChild(btnEditar);
        li.appendChild(btnDeletar);

        listaEstudos.appendChild(li);
      });
    })
    .catch(erro => console.error('Erro ao carregar estudos:', erro));
}

// Função para iniciar edição
function editarEstudo(id, titulo, descricao) {
  estudoEditandoId = id;
  tituloInput.value = titulo;
  descricaoInput.value = descricao;
  formEstudo.querySelector('button[type="submit"]').textContent = 'Salvar edição';
}

// Evento para enviar (cadastrar ou editar)
formEstudo.addEventListener('submit', (e) => {
  e.preventDefault();

  const dadosEstudo = {
    titulo: tituloInput.value,
    descricao: descricaoInput.value
  };

  if (estudoEditandoId) {
    // Atualizar estudo existente
    fetch(`http://localhost:3000/estudos/${estudoEditandoId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dadosEstudo)
    })
      .then(() => {
        estudoEditandoId = null;
        tituloInput.value = '';
        descricaoInput.value = '';
        formEstudo.querySelector('button[type="submit"]').textContent = 'Adicionar estudo';
        carregarEstudos();
      })
      .catch(erro => console.error('Erro ao editar estudo:', erro));
  } else {
    // Criar novo estudo
    fetch('http://localhost:3000/cadastro', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dadosEstudo)
    })
      .then(() => {
        tituloInput.value = '';
        descricaoInput.value = '';
        carregarEstudos();
      })
      .catch(erro => console.error('Erro ao adicionar estudo:', erro));
  }
});

// Deletar estudo
function deletarEstudo(id) {
  fetch(`http://localhost:3000/estudos/${id}`, {
    method: 'DELETE'
  })
    .then(() => carregarEstudos())
    .catch(erro => console.error('Erro ao deletar estudo:', erro));
}

// Inicia a lista na tela
carregarEstudos();

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('form-estudo');

  // Função para listar estudos na tela
  function listarEstudos(estudos) {
    const listaEstudos = document.getElementById('lista-estudos');
    listaEstudos.innerHTML = ''; // limpa lista

    estudos.forEach(estudo => {
      const li = document.createElement('li');
      li.className = 'estudo-card';

      li.innerHTML = `
        <h3>${estudo.titulo}</h3>
        <p>${estudo.descricao}</p>
        <button class="btn btn-editar" data-id="${estudo.id}">Editar</button>
        <button class="btn btn-deletar" data-id="${estudo.id}">Deletar</button>
      `;

      listaEstudos.appendChild(li);
    });

    // Adiciona eventos aos botões depois que criaram os elementos
    document.querySelectorAll('.btn-deletar').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.target.getAttribute('data-id');
        deletarEstudo(id);
      });
    });

    // Aqui poderia adicionar evento para editar depois
  }

  // Função para buscar estudos da API
  function carregarEstudos() {
    fetch('/estudos')
      .then(res => res.json())
      .then(data => listarEstudos(data))
      .catch(err => console.error('Erro ao carregar estudos:', err));
  }

  // Função para deletar estudo
  function deletarEstudo(id) {
    fetch(`/estudos/${id}`, {
      method: 'DELETE'
    })
    .then(res => {
      if(res.ok){
        carregarEstudos(); // atualiza a lista depois de deletar
      } else {
        alert('Erro ao deletar estudo');
      }
    })
    .catch(err => console.error('Erro ao deletar:', err));
  }

  // Enviar o formulário para cadastrar novo estudo
  form.addEventListener('submit', e => {
    e.preventDefault();

    const titulo = document.getElementById('titulo').value.trim();
    const descricao = document.getElementById('descricao').value.trim();

    if(!titulo || !descricao) {
      alert('Preencha todos os campos');
      return;
    }

    fetch('/cadastro', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ titulo, descricao })
    })
    .then(res => {
      if(res.ok){
        form.reset();
        carregarEstudos();
      } else {
        alert('Erro ao cadastrar estudo');
      }
    })
    .catch(err => console.error('Erro ao cadastrar:', err));
  });

  // Carregar estudos assim que a página abrir
  carregarEstudos();
});
